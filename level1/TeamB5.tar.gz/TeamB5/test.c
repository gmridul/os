#include<stdio.h>
#include<stdlib.h>
#include<sys/syscall.h>

int main()
{
	char a[5];
	a[0] = 'a';
	a[1] = 'b';
	a[2] = 'c';
	a[3] = 'd';
	a[4] = 'e';

	syscall(403, 5, a, 10, 1);
	syscall(402, 5, a, 10, 1);
	
	int j =0;
	for(j=0;j<200;j++)
	{
		printf("j is %d\n", j);
		fflush(stdout);
	}	
	return 0;

}
